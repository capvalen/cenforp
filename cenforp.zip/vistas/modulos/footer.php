<footer class="main-footer">
	
	<strong>Copyright &copy; 2023 <a href="https://www.cenforp.com/" target="_blank">CENFORP</a>.</strong>

	Todos los derechos reservados.


</footer>